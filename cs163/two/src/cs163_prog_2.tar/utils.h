int user_input(int start, int stop);
void user_input_str(char *&to_fill);
void user_input_str(char *&temp, char *&to_fill);
